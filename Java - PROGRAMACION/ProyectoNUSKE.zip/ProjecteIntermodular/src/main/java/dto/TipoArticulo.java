package dto;

public enum TipoArticulo {
    CAMAS, CORREAS, TRANSPORTINES, COMEDEROS, PELOTAS, MORDEDORES, PELUCHES, JUGUETES_INTERACTIVOS, CHAMPUS, BOLSAS_CALLE, ANTIPARASITOS, EMPAPADORES, PIENSOS, SNACKS, COMIDAS_HUMEDAS, OTROS;
    
//    @Override
//    public String toString() {
//        switch(this) {
//            case CAMAS:
//                return "Camas";
//                
//            case CORREAS:
//                return "Correas";
//                
//            case TRANSPORTINES:
//                return "Transportines";
//                    
//            case COMEDEROS:
//                return "Comederos";
//                        
//            case PELOTAS:
//                return "Pelotas";
//                        
//            case MORDEDORES:
//                return "Mordedores";
//                        
//            case PELUCHES:
//                return "Peluches";
//                        
//            case JUGUETES_INTERACTIVOS:
//                return "Juguetes interactivos";
//                        
//            case CHAMPUS:
//                return "Champús";
//                        
//            case BOLSAS_CALLE:
//                return "Bolsas de calle";
//                        
//            case ANTIPARASITOS:
//                return "Antiparásitos";
//                            
//            case EMPAPADORES:
//                return "Empapadores";    
//                
//            case PIENSOS:
//                return "Piensos";   
//                
//            case SNACKS:
//                return "Snacks";
//                    
//            case COMIDAS_HUMEDAS:
//                return "Comidas húmedas";
//                    
//            case OTROS:
//                return "Otros";
//                
//        }
//        
//        return null;
//    }
}
