package dto;

public enum EstadoPedido {
    PENDIENTE_DE_PAGO, PROCESANDO, EN_ESPERA, COMPLETADO, CANCELADO;
    
//    @Override
//    public String toString() {
//        switch(this) {
//            case PENDIENTE_DE_PAGO:
//                return "Pediente de pago";
//                
//            case PROCESANDO:
//                return "Procesando";
//                
//            case EN_ESPERA:
//                return "En espera";
//                    
//            case COMPLETADO:
//                return "Completado";
//                    
//            case CANCELADO:
//                return "Cancelado";
//        }
//        
//        return null;
//    }
}
