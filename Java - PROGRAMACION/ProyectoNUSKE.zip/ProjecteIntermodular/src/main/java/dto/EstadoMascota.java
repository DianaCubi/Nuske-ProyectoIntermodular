package dto;

public enum EstadoMascota {
    EN_CASA, VULNERABLE, PERDIDA;

//    @Override
//    public String toString() {
//
//        switch (this) {
//            case EN_CASA:
//                return "En Casa";
//            case VULNERABLE:
//                return "Vulnerable";
//            case PERDIDA:
//                return "Perdida";
//
//        }
//
//        return null;
//    }

}
