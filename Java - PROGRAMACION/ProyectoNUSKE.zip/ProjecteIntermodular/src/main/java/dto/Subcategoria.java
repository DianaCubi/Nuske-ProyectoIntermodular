package dto;

public enum Subcategoria {
    HOGAR, ENTRETENIMIENTO, SALUD_E_HIGIENE, ALIMENTACION;
    
//    @Override
//    public String toString() {
//        switch(this) {
//            case HOGAR:
//                return "Hogar";
//                
//            case ENTRETENIMIENTO:
//                return "Entretenimiento";
//                
//            case SALUD_E_HIGIENE:
//                return "Salud e higiene";
//                    
//            case ALIMENTACION:
//                return "Alimentación";
//        }
//        
//        return null;
//    }
}
