
package dto;

public enum ListaProvincias {

    A_CORUNA, ALAVA, ALBACETE, ALICANTE,
    ALMERIA, ASTURIAS, AVILA, BADAJOZ, BALEARES,
    BARCELONA, BURGOS, CACERES, CADIZ, CANTABRIA,
    CASTELLON, CIUDAD_REAL, CORDOBA, CUENCA, GIRONA,
    GRANADA, GUADALAJARA, GIPUZKOA, HUELVA, HUESCA,
    JAEN, LA_RIOJA, LAS_PALMAS, LEON, LERIDA, LUGO,
    MADRID, MALAGA, MURCIA, NAVARRA, OURENSE, PALENCIA,
    PONTEVEDRA, SALAMANCA, SEGOVIA, SEVILLA, SORIA, TARRAGONA,
    SANTA_CRUZ_DE_TENERIFE, TERUEL, TOLEDO, VALENCIA, VALLADOLID,
    VIZCAYA, ZAMORA, ZARAGOZA, CEUTA, MELILLA;

//    public String toString() {
//        switch (this) {
//            case A_CORUNA:
//                return "A Coruña";
//            case ALAVA:
//                return "Alava";
//            case ALBACETE:
//                return "Albacete";
//            case ALICANTE:
//                return "Alicante";
//            case ALMERIA:
//                return "Almeria";
//            case ASTURIAS:
//                return "Asturias";
//            case AVILA:
//                return "Avila";
//            case BADAJOZ:
//                return "Badajoz";
//            case BALEARES:
//                return "Baleares";
//            case BARCELONA:
//                return "Barcelona";
//            case BURGOS:
//                return "Burgos";
//            case CACERES:
//                return "Caceres";
//            case CADIZ:
//                return "Cadiz";
//            case CANTABRIA:
//                return "Cantabria";
//            case CASTELLON:
//                return "Castellón";
//            case CIUDAD_REAL:
//                return "Ciudad Real";
//            case CORDOBA:
//                return "Cordoba";
//            case CUENCA:
//                return "Cuenca";
//            case GIRONA:
//                return "Girona";
//            case GRANADA:
//                return "Granada";
//            case GUADALAJARA:
//                return "Guadalajara";
//            case GIPUZKOA:
//                return "Guipuzkoa";
//            case HUELVA:
//                return "Huelva";
//            case HUESCA:
//                return "Huesca";
//            case JAEN:
//                return "Jaen";
//            case LA_RIOJA:
//                return "La Rioja";
//            case LAS_PALMAS:
//                return "Las Palmas";
//            case LEON:
//                return "Leon";
//            case LERIDA:
//                return "Lerida";
//            case LUGO:
//                return "Lugo";
//            case MADRID:
//                return "Madrid";
//            case MALAGA:
//                return "Malaga";
//            case MURCIA:
//                return "Murcia";
//            case NAVARRA:
//                return "Navarra";
//            case OURENSE:
//                return "Ourense";
//            case PALENCIA:
//                return "Palencia";
//            case PONTEVEDRA:
//                return "Pontevedra";
//            case SALAMANCA:
//                return "Salamanca";
//            case SEGOVIA:
//                return "Segovia";
//            case SEVILLA:
//                return "Sevilla";
//            case SORIA:
//                return "Soria";
//            case TARRAGONA:
//                return "Tarragona";
//            case SANTA_CRUZ_DE_TENERIFE:
//                return "Santa Cruz de Tenerife";
//            case TERUEL:
//                return "Teruel";
//            case TOLEDO:
//                return "Toledo";
//            case VALENCIA:
//                return "Valencia";
//            case VALLADOLID:
//                return "Valladolid";
//            case VIZCAYA:
//                return "Vizcaya";
//            case ZAMORA:
//                return "Zamora";
//            case ZARAGOZA:
//                return "Zaragoza";
//            case CEUTA:
//                return "Ceuta";
//            case MELILLA:
//                return "Melilla";
//        }
//            return null;
//    }
}
