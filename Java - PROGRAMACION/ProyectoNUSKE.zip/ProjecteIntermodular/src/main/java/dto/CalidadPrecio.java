package dto;

import java.text.Normalizer;

public enum CalidadPrecio {
    EXCELENTE, MUY_BUENA, BUENA, ACEPTABLE, NORMAL, MALA, MUY_MALA;
    
//            
//    @Override
//    public String toString() {
//        switch(this) {
//            case EXCELENTE:
//                return "Excelente";
//                
//            case MUY_BUENA:
//                return "Muy buena";
//                
//            case BUENA:
//                return "Buena";
//                
//            case ACEPTABLE:
//                return "Aceptable";
//                    
//            case NORMAL:
//                return "Normal";
//                    
//            case MALA:
//                return "Mala";
//                    
//            case MUY_MALA:
//                return "Muy mala";
//        }
//        
//        return null;
//    }
}
